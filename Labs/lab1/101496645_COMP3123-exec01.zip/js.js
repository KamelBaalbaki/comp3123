function capitalizeFirstLetter(str) {
    return str.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
}

console.log(capitalizeFirstLetter("hello my old friend"));

function largestBetweenThreeNumbers(num1, num2, num3) {
    let largest;

    if (num1 >= num2 && num1 >= num3) {
        largest = num1;
    }
    else if (num2 >= num1 && num2 >= num3) {
        largest = num2;
    }
    else {
        largest = num3;
    }

    return largest;
}

console.log(largestBetweenThreeNumbers(8,66,-7))

function moveLastThreeLetters(str) {
    if (str.length < 3) {
        return "Error: The string must be at least three characters long.";
    }

    const lastThreeCharacters = str.slice(-3);

    const remainingCharacters = str.slice(0, -3);

    return lastThreeCharacters + remainingCharacters;
}

console.log(moveLastThreeLetters("Morning"));


function getAngleType(angle) {
    switch (true) {
        case (angle > 0 && angle < 90):
            return "Acute angle";
            break;

        case (angle === 90):
            return "Right angle";
            break;

        case (angle > 90 && angle < 180):
            return "Obtuse angle";
            break;

        case (angle === 180):
            return "Straight angle";
            break;

        default:
            return "Invalid angle";
    }
}

console.log("The type of the angle 170 is: " + getAngleType(170))